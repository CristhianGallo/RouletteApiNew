package com.controller;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.model.Bet;
import com.model.Roulette;
import com.model.Winner;
import com.service.*;

import java.util.List;

@RestController
@RequestMapping("/api/Roulette")
public class RouletteController {
		
	@Autowired
	private IRouletteService service;
	
	
	@PostMapping("/create")
	public ResponseEntity<Roulette> getRoulette() {		
		ResponseEntity response =null;
		try {
			//Roulette roul = service.createRoulette();
			Roulette roul = new Roulette();
			roul.setStatus("N");
			service.Save(roul);
			response = ResponseEntity.ok(roul);
		}catch(Exception ex)
		{
			JSONObject jsonResponse = new JSONObject();
			jsonResponse.put("Error",ex.toString());
			response =  ResponseEntity.badRequest().body(jsonResponse.toString());
		}
		
		return response;
	}
	
/*
	@PutMapping("/open")
	public ResponseEntity<String> openRoulette(@RequestParam(value="id") long id) {		
		ResponseEntity response =null;
		try {
			if(service.openRoulette(id)) response = ResponseEntity.status(HttpStatus.OK).body("Operación exitosa");
			else response = ResponseEntity.status(HttpStatus.NOT_FOUND).body("Operación falló");
		}catch(Exception ex)
		{
			response =  ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.toString());
		}
		
		return response;
	}
	
	
	
	@PostMapping("/bet")
	public ResponseEntity<Bet> betRoulette(@RequestBody Bet bet, @RequestHeader("user_id") String user_id )
	{
		ResponseEntity response =null;
		
		try {
			bet.setUserId(user_id);
			Bet newbet = service.betRoulette(bet); 
			response = ResponseEntity.ok(newbet);
		}catch(Exception ex)
		{
			JSONObject jsonResponse = new JSONObject();
			jsonResponse.put("Error",ex.toString());
			response =  ResponseEntity.badRequest().body(jsonResponse.toString());
		}
		
		return response;
	}

	
	
	@PutMapping("/executeRulette")
	public <T> ResponseEntity<T> execRulette(@RequestParam(value="id") long id) {		
		ResponseEntity response =null;
		List<Winner> winners;
		try {
			winners = service.executeRoulette(id);
			response = ResponseEntity.ok(winners);
		}catch(Exception ex)
		{
			response =  ResponseEntity.badRequest().body(ex.toString());
		}
		
		return response;
	}
	
	
	
	@GetMapping("/getAllRouletes")
	public <T> ResponseEntity<T> getAllRouletes() {		
		ResponseEntity response =null;
		List<Roulette> roulettes;
		try {
			roulettes = service.getAllRoulettes();
			response = ResponseEntity.ok(roulettes);
		}catch(Exception ex)
		{
			response =  ResponseEntity.badRequest().body(ex.toString());
		}
		
		return response;
	}
	*/
	
}
