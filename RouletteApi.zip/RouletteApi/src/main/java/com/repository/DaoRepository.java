package com.repository;

import static com.utils.Constants.CLOSED_ROULETTE;
import static com.utils.Constants.CREATED_ROULETTE;
import static com.utils.Constants.NULL_INTEGER;
import static com.utils.Constants.OPEN_ROULETTE;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

//Permitir usar la notación "Repository", para poder hacer inyección de esta clase en otro lado
import org.springframework.stereotype.Repository;

import com.dbConnection.IDBOperations;
import com.model.Bet;
import com.model.Roulette;
import com.model.Winner;

//La etiqueta "Repository" Indica que esta clase es usada como punto de acceso a datos, y tambien permitirá hacer inyección de dependencias con esta clase.
@Repository
public class DaoRepository implements IDBOperations{

	
	public Long createRouletteRecord()
	{
		String sql = "INSERT INTO roulette (status_) VALUES ('"+CREATED_ROULETTE+"');";
		return insertRecord(sql);
	}
	
	
	public boolean openRoulette(Long id)
	{
		String update = "UPDATE roulette set status_ = '"+OPEN_ROULETTE+"' WHERE id ="+id;
		return updateRecord(update);
	}
	
	
	public boolean closeRoulette(Long id) {
		String update = "UPDATE roulette set status_ = '"+CLOSED_ROULETTE+"' WHERE id ="+id;
		return updateRecord(update);
	}
	
	
	public Long createBetRecordByNumber(Bet bet)
	{
		String sql = "INSERT INTO bet_roulette (bet_amount, bet_number, id_roulette, id_customer) "
				   + "VALUES ("+bet.getBetMoneyAmount()+", "+bet.getNumber()+","+bet.getRouletteId()+", '"+bet.getUserId()+"');";
		
		return insertRecord(sql);
	}
	
	public Long createBetRecordByColor(Bet bet) {
		String sql = "INSERT INTO bet_roulette (bet_amount, bet_color, id_roulette, id_customer) "
				   + "VALUES ("+bet.getBetMoneyAmount()+", '"+bet.getColor()+"', "+bet.getRouletteId()+", '"+bet.getUserId()+"');";
		
		return insertRecord(sql);
	}
	
	
	@Override
	public long insertRecord(String sql) {
		long id =0;
		try(Connection connection = connecToDB())
		{
			Statement statement = connection.createStatement();
			statement.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS); 
			ResultSet rs = statement.getGeneratedKeys();
			if (rs.next()) id =rs.getInt(1);
	        rs.close();
	        statement.close();
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return id;
	}

	@Override
	public boolean updateRecord(String sql) {
		boolean updated = false;
		try(Connection connection = connecToDB())
		{
			Statement statement = connection.createStatement();
			if(statement.executeUpdate(sql) > 0) updated = true;
			else updated = false;
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return updated;
		
	}

	@Override
	public boolean deleteRecord(String sql) {
		// TODO Auto-generated method stub
		return false;
	}

	
	public List<Winner> getWinners(long idRoulette, int number, String color)
	{
		List<Winner> winners = new ArrayList<Winner>(); 	
		try(Connection connection = connecToDB()){
			String query = "select id_customer, id, bet_number, bet_color, bet_amount FROM bet_roulette WHERE id_roulette ="+idRoulette+ " "
					     + "AND (bet_number = "+number+" OR bet_color='"+color+"')";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) {
				int betNumber =  ((rs.getString("bet_number")) == null) ? NULL_INTEGER : Integer.valueOf(rs.getString("bet_number"));
				Winner win = new Winner(rs.getString("id_customer"), Long.valueOf(rs.getString("id")), 
						                Double.valueOf(rs.getString("bet_amount")), betNumber,rs.getString("bet_color"));	
				winners.add(win); 
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return winners;
	}
	
	
	public List<Roulette> getAllRoulettes() {
		List<Roulette> roulettes = new ArrayList<Roulette>(); 
		String status;
		try(Connection connection = connecToDB()){
			String query = "select id, status_ FROM roulette; ";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) {				
				if( rs.getString("status_").equals(CREATED_ROULETTE))  status = "Creada";
				else if(rs.getString("status_").equals(OPEN_ROULETTE)) status = "Abierta";
				else status = "Cerrada";
				Roulette roul = new Roulette(Long.valueOf(rs.getString("id")), status);	
				roulettes.add(roul); 
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return roulettes;
	}
	
	
	public Roulette getRouleteById(Long id) {
		String sql = "SELECT id,status_ FROM roulette WHERE id="+id;
		Roulette record= null;
		try(Connection connection = connecToDB())
		{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement = connection.prepareStatement(sql);
			ResultSet rs = null;		
			rs = preparedStatement.executeQuery();
			if(rs.next()) record = new Roulette(Long.valueOf(rs.getString("id")), rs.getString("status_"));
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return record;
	}
	
	
	
}
