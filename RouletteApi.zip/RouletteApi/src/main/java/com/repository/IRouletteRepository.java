package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.Roulette;

//La etiqueta "Repository" Indica que esta clase es usada como punto de acceso a datos, y tambien permitirá hacer inyección de dependencias con esta clase.
@Repository
public interface IRouletteRepository extends JpaRepository<Roulette, Long> {

}
