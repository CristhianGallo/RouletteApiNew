package com.utils;

public class Constants {

	public static final String RED = "rojo";
	public static final String BLACK = "negro";
	public static final int ZERO = 0;
	public static final int MAX_AMOUNT = 10000;
	public static final int NULL_INTEGER = -100;
	
	public static final String URL = "jdbc:mysql://remotemysql.com:3306/";
	public static final String DB_NAME = "eGswfSl1CS";
	public static final String DB_USER = "eGswfSl1CS";
	public static final String DB_PASSWORD = "4AFwdh3XbS";
		
	public static final String CREATED_ROULETTE = "N";
	public static final String OPEN_ROULETTE = "O";
	public static final String CLOSED_ROULETTE = "C";
	
	public static final int EMPTY_ROULETTE_ID = 50;
	public static final int UNEXIST_ROULETTE_ERR = 100;
	public static final int INVALID_ROULETTE_ERR = 200;
	public static final int NON_UPDATED_RECORD = 300;
	public static final int INVALID_NUMBER = 400;
	public static final int INVALID_BET_PARAMS = 500;
	public static final int INVALID_COLOR = 600;
	public static final int INVALID_BET_AMOUNT = 700;
	public static final int INVALID_USER_ID = 800;
}
