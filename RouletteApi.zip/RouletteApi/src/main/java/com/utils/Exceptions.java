package com.utils;
import static com.utils.Constants.*;

public class Exceptions  extends Exception{

	private static final long serialVersionUID = 1L;

	private int errCode;
	
	public Exceptions(int errCode) {
		super();
		this.errCode = errCode;
	}
	
	
	@Override
	public String getMessage() {
		String errMsg;
		switch(this.errCode) {
			case EMPTY_ROULETTE_ID: errMsg = "Error, debe ingresar un identificador valido para la ruleta";
				break;
			case UNEXIST_ROULETTE_ERR: errMsg = "Error, el identificador ingresado no corresponde a ninguna ruleta";
				break;
			case INVALID_ROULETTE_ERR: errMsg = "Error, el identificador ingresado corresponde a una ruleta no disponible para esta operación";
				break;
			case NON_UPDATED_RECORD: errMsg = "Error, no ha sido posible actualizar el registro";
				break;
			case INVALID_NUMBER: errMsg = "Error, el número ingresado en la apuesta debe estar entre 0 y 36";
				break;
			case INVALID_BET_PARAMS: errMsg = "Error, el usuario solo puede apostar a un color o a un número, pero no a ambos";
				break;
			case INVALID_COLOR: errMsg = "Error, el usuario solo puede apostar a un color negro o a un color rojo";
				break;
			case INVALID_BET_AMOUNT: errMsg = "Error, el valor a apostar debe estar entre 1 y 10000";
				break;
			case INVALID_USER_ID: errMsg = "Error, debe haber un usuario autenticado";
			default: errMsg = "Error no especificado, por favor comuniquese con el proveedor de servicios";
		}
		
		return errMsg;
	}
	
	
}
