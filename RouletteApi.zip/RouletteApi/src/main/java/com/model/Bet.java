package com.model;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.NotNull; //esto se usa gracias a la dependencia "org.hibernate.validator" agregada en el archivo "pom"
import javax.validation.constraints.Size;    //esto se usa gracias a la dependencia "org.hibernate.validator" agregada en el archivo "pom"

//Permitir mapear esta entidad usando JPA
@Entity
//Como la clase no se llama igual a la entidad en la Bd, se usa la siguiente notación:
@Table(name="bet_roulette")
public class Bet implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	@Id
	@Column(name="id")//Como la columna no se llama igual que en la entidad, se usa esta notación
	@GeneratedValue(strategy = GenerationType.IDENTITY) //Esto para generar automáticamente los identificadores (auto incremento)
	private Long rouletteId;
	
	@Column(name="bet_color", length=10)//Como la columna no se llama igual que en la entidad, se usa esta notación
	private String color;
	
	@Column(name="bet_number")//Como la columna no se llama igual que en la entidad, se usa esta notación
	private Integer number;
	
	@Column(name="bet_customer", nullable=false)//Como la columna no se llama igual que en la entidad y se requiere, se usa esta notación
	private String userId;
	
	@Column(name="bet_amount", nullable=false)//Como la columna no se llama igual que en la entidad y se requiere, se usa esta notación
	private Integer betMoneyAmount;
	
	
	public Bet() {
	}


	public Bet(String color, Integer number, Long roulette_id, String userId, Integer betMoneyAmount) {
		super();
		this.color = color;
		this.number = number;
		this.rouletteId = roulette_id;
		this.userId = userId;
		this.betMoneyAmount = betMoneyAmount;
	}
	
	
	
	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	public Integer getNumber() {
		return this.number;
	}


	public void setNumber(Integer number) {
		this.number = number;
	}

	
	public Long getRouletteId() {
		return rouletteId;
	}


	public void setRouletteId(Long roulette_id) {
		this.rouletteId = roulette_id;
	}



	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}




	public Integer getBetMoneyAmount() {
		return betMoneyAmount;
	}




	public void setBetMoneyAmount(Integer betMoneyAmount) {
		this.betMoneyAmount = betMoneyAmount;
	}




	@Override
	public String toString() {
		return "Bet [color=" + color + ", number=" + number + ", rouletteId=" + rouletteId + ", userId=" + userId
				+ ", betMoneyAmount=" + betMoneyAmount + "]";
	}



	

	
	
}
