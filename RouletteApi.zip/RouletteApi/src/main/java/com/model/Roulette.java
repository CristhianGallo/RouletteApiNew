package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//Permitir mapear esta entidad usando JPA
@Entity
//Como la clase no se llama igual a la entidad en la Bd, se usa la siguiente notación:
@Table(name="roulette")
public class Roulette {
	
	@Id
	@Column(name="id")//Como la columna no se llama igual que en la entidad, se usa esta notación
	@GeneratedValue(strategy = GenerationType.IDENTITY) //Esto para generar automáticamente los identificadores (auto incremento)
	private Long id;
	
	@Column(name="bet_customer", length=1, nullable=false)//Como la columna no se llama igual que en la entidad y se requiere, se usa esta notación
	private String status;
	
	
	public Roulette() {
	}
	
	
	
	public Roulette(Long id, String status) {
		this.id = id;
		this.status = status;
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	@Override
	public String toString() {
		return "Roulette [id=" + id + ", status=" + status + "]";
	}
	
	
}
