package com.model;

public class Winner {

	private String userId;
	private Long betId;
	private Double amountEarn;
	private Integer  number;
	private String color;
	

	public Winner() {
		super();
	}



	public Winner(String userId, Long betId, Double amountEarn, Integer number, String color) {
		super();
		this.userId = userId;
		this.betId = betId;
		this.amountEarn = amountEarn;
		this.number = number;
		this.color = color;
	}



	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public Long getBetId() {
		return betId;
	}


	public void setBetId(Long betId) {
		this.betId = betId;
	}



	public double getAmountEarn() {
		return amountEarn;
	}



	public void setAmountEarn(Double amountEarn) {
		this.amountEarn = amountEarn;
	}



	public int getNumber() {
		return number;
	}



	public void setNumber(Integer number) {
		this.number = number;
	}



	public String getColor() {
		return color;
	}



	public void setColor(String color) {
		this.color = color;
	}



	@Override
	public String toString() {
		return "Winner [userId=" + userId + ", betId=" + betId + ", amountEarn=" + amountEarn + ", number=" + number
				+ ", color=" + color + "]";
	}

	
}

