package com.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.model.Roulette;

public interface IRouletteService {

	public Iterable<Roulette> findAll();
	
	
	public Page<Roulette> findall(Pageable pageable);
	
	
	public Optional<Roulette> findById(Long id);
	
	
	public Roulette Save(Roulette entity);
	
	
	public void deleteById(Long id);
}
