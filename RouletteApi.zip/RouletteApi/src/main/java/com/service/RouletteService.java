package com.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.model.Bet;
import com.model.Roulette;
import com.model.Winner;
import com.repository.DaoRepository;
import com.repository.IRouletteRepository;
import com.utils.Exceptions;
import static com.utils.Constants.*;

//La etiqueta "@Service", Indica que esto son servicios y tambien peritirá hacer inyección de esta clase en otro lado
@Service
public class RouletteService implements IRouletteService{

	/*
	@Autowired
	private DaoRepository dao;
	*/
	
	@Autowired
	private IRouletteRepository rouletteRepository;
	
	
	@Override
	@Transactional(readOnly=true)//Es una transacción de solo lectura. Osea no cambia nada en la BD
	public Iterable<Roulette> findAll() {
		return rouletteRepository.findAll();
	}



	@Override
	@Transactional(readOnly=true)//Es una transacción de solo lectura. Osea no cambia nada en la BD
	public Optional<Roulette> findById(Long id) {
		return rouletteRepository.findById(id);
	}



	@Override
	@Transactional //Es una transacción que cambia registros en la BD
	public Roulette Save(Roulette entity) {
		return rouletteRepository.save(entity);
	}



	@Override
	@Transactional //Es una transacción que cambia registros en la BD
	public void deleteById(Long id) {
		rouletteRepository.deleteById(id);		
	}
	
	
	
	/*
	public Roulette createRoulette() {
		//Roulette roul = new Roulette();
		//roul.setStatus(CREATED_ROULETTE);
		//return rouletteRep.save(roul);
		
		Long rouletteId = dao.createRouletteRecord();
		return new Roulette (rouletteId, CREATED_ROULETTE);
	}

	
	
	public boolean openRoulette(long id) throws Exceptions{
		boolean response = false;
		
		try {
				if(valRouletteById(id, CREATED_ROULETTE)) 
				{
					if(!dao.openRoulette(id)) throw new Exceptions(NON_UPDATED_RECORD); 
					else response = true;
				}
				else response = false;				
		}finally {}
		
		return response;
	}

		
	
	public Bet betRoulette(Bet bet) throws Exceptions{
		Long betId;
		try {
			Optional<Integer> betNumber, betMaount; 
			betNumber = Optional.ofNullable(bet.getNumber());
			betMaount = Optional.ofNullable(bet.getBetMoneyAmount());		
			Optional<Long> betRouletteId = Optional.ofNullable(bet.getRouletteId());	
			
			boolean hasColor = (bet.getColor() ==null || bet.getColor().equals(""))? false : true; 
			
			if(betNumber.isPresent() && hasColor) throw new Exceptions(INVALID_BET_PARAMS);
			if(betNumber.isPresent() && (bet.getNumber() <ZERO || bet.getNumber() > 36)) throw new Exceptions(INVALID_NUMBER);
			if(hasColor  && !bet.getColor().toLowerCase().equals(RED) && !bet.getColor().toLowerCase().equals(BLACK)) throw new Exceptions(INVALID_COLOR);
			if(betMaount.isPresent() && (bet.getBetMoneyAmount() <=ZERO || bet.getBetMoneyAmount() > MAX_AMOUNT)) throw new Exceptions(INVALID_BET_AMOUNT);
			if(!betRouletteId.isPresent() || bet.getRouletteId() == ZERO) throw new Exceptions(EMPTY_ROULETTE_ID);
			if(bet.getUserId() == null || bet.getUserId().equals("")) throw new Exceptions(INVALID_USER_ID);
			
			valRouletteById(bet.getRouletteId(),OPEN_ROULETTE);
			
			if(betNumber.isPresent())
				betId = dao.createBetRecordByNumber(bet);
			else
				betId = dao.createBetRecordByColor(bet);
		}finally {}	
		
		bet.setRouletteId(betId);
		return bet;
	}

	
	
	public List<Winner> executeRoulette(long id) throws Exceptions{
		int executeRulettte =  (int) (Math.random()*36 + 1); 
		String color;
		
		valRouletteById(id,OPEN_ROULETTE);
		color = (executeRulettte%2==ZERO) ? RED : BLACK;
		
		List<Winner> winners = dao.getWinners(id, executeRulettte, color)
				                         .stream()
				                         .map( winner -> { 
				                        	   Optional<Integer> betNumber = Optional.ofNullable(winner.getNumber());
				                        	 
				                        	   if( betNumber.isPresent() ) winner.setAmountEarn( winner.getAmountEarn()*5.0);
				                        	   else winner.setAmountEarn(winner.getAmountEarn()*1.8);
                							   return winner;
				                         })
                                         .collect(Collectors.toList()); 
		
		if(!dao.closeRoulette(id)) throw new Exceptions(NON_UPDATED_RECORD); 
		
		return winners;
	}


	
	
	public List<Roulette> getAllRoulettes() {	
		return dao.getAllRoulettes();
	}

	
	public boolean valRouletteById(Long id, String validStatus) throws Exceptions{
		boolean response = false;
		
		try{
			Roulette roulette =  dao.getRouleteById(id);
			if(roulette != null) 
			{
				if(!roulette.getStatus().equals(validStatus)) throw new Exceptions(INVALID_ROULETTE_ERR);
				else response = true;
			}
			else throw new Exceptions(UNEXIST_ROULETTE_ERR);
		}finally {}
		
		return response;
	}
    */
 

	
	
	
	
}

