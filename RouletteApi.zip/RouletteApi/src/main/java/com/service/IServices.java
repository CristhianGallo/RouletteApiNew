package com.service;

import java.util.List;

import com.model.Bet;
import com.model.Roulette;
import com.model.Winner;
import com.utils.Exceptions;


public interface IServices {
	
	
	public Roulette createRoulette();
	
	public boolean openRoulette(long id) throws Exceptions;
	
	public Bet betRoulette(Bet bet) throws Exceptions;
	
	public List<Winner> executeRoulette(long id) throws Exceptions;
	
	public List<Roulette> getAllRoulettes();

}
