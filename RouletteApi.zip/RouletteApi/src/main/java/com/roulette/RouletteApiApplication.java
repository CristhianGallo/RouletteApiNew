package com.roulette;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//La siguiente linea es pars que reconozca el paquete donde se encuentra el controlador y el paquete
//donde se encuentra la interfaz que se quiere usar para inyectar al controller
@ComponentScan(basePackages = {"com.controller,com.service,com.repository"})
public class RouletteApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RouletteApiApplication.class, args);
	}

}
