package com.Roulette;

import static org.junit.jupiter.api.Assertions.*;
//Permitir usar mocks
import static org.mockito.Mockito.mock;
//Permirir usar stubbing con los mocks:
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.model.Bet;
import com.model.Roulette;
import com.service.IServices;
import com.utils.Exceptions;

//Integrar JUNIT con mockito
@ExtendWith(MockitoExtension.class)
//Permirir integrar las notaciones de spring con JUNIT, como por ej "Autowired"
@ExtendWith(SpringExtension.class)
//Permirir usar las notaciones de spring con JUNIT, como por ej "Autowired" (se utiliza para testear un contexto web sin levantar un servidor Http completo)
@WebMvcTest
class ServiceTests {

	@Autowired
	private IServices service;
	
	@Mock
	Bet mockBet;
	
	
	
	@Test
	@DisplayName("Create Roulette")
	void createRoulette() {
		
		Roulette roulette = service.createRoulette();
		System.out.println("Creado: "+roulette.getId());
		assertNotNull(roulette, "ERROR: No se ha creado ninguna ruleta");
		
	}

	
	@Test
	@DisplayName("Open Roulette")
	void openRoulette() throws Exceptions {
		
		Roulette roulette = service.createRoulette();
		assertNotNull(roulette, "ERROR: No se ha creado una ruleta");
		
		//Abrir la ruleta creada:
		assertTrue(service.openRoulette(roulette.getId()),"ERROR: No se pudo abrir la ruleta");
		
	}
	
	@Test
	@DisplayName("Set Bet")
	void setBet() throws Exceptions {
		
		/* Inicializar el objeto que simula una instancia de la clase "Bet" */
		mockBet = mock(Bet.class);
		
		//STUBBING (Simular comportamiento del mock como si fuera un objeto de la clsse "Bet"):
		when(mockBet.getNumber()).thenReturn(null); 
		when(mockBet.getColor()).thenReturn("Rojo");
		when(mockBet.getBetMoneyAmount()).thenReturn(8000);
		when(mockBet.getRouletteId()).thenReturn((long) 50);
		when(mockBet.getUserId()).thenReturn("A312");
		
		System.out.println("NUMERO: "+mockBet.getNumber());
		System.out.println("COLOR: "+mockBet.getColor());
		System.out.println("BET AMOUNT: "+mockBet.getBetMoneyAmount());
		System.out.println("ROULETTE ID: "+mockBet.getRouletteId());
		System.out.println("USER ID: "+mockBet.getUserId());
		
		Bet bet = service.betRoulette(mockBet);
		
		assertNotNull(bet, "ERROR: No se ha creado ninguna apuesta");
	}
	
	
	@Test
	@DisplayName("Set Bad Bet")
	void setBadBet() throws Exceptions {
		
		/* Inicializar el objeto que simula una instancia de la clase "Bet" */
		mockBet = mock(Bet.class);
		
		//STUBBING (Simular comportamiento del mock como si fuera un objeto de la clsse "Bet"):
		when(mockBet.getNumber()).thenReturn(123); 
		when(mockBet.getColor()).thenReturn("Rojo");
		when(mockBet.getBetMoneyAmount()).thenReturn(8000);
		when(mockBet.getRouletteId()).thenReturn((long) 50);
		when(mockBet.getUserId()).thenReturn("A312");
		
		System.out.println("NUMERO: "+mockBet.getNumber());
		System.out.println("COLOR: "+mockBet.getColor());
		System.out.println("BET AMOUNT: "+mockBet.getBetMoneyAmount());
		System.out.println("ROULETTE ID: "+mockBet.getRouletteId());
		System.out.println("USER ID: "+mockBet.getUserId());
		
		//Esperar una excepción
		Assertions.assertThrows(Exceptions.class,() -> {
		      service.betRoulette(mockBet);
	    });
		
	}
	
	
	
}
